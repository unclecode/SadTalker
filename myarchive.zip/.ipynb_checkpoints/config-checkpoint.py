MODEL_ID="eleven_monolingual_v1"
VOICE_SETTINGS = {
        "similarity_boost": 0.5,
        "stability": 0.5,
        "style": 0.5,
        "use_speaker_boost": True
    }